# Portafolio de Carlos Arturo Velasquez Alvarez

Este proyecto contiene un portafolio profesional en un solo archivo: `index.html`.

## Publicarlo gratis con GitHub Pages

1. Entra a GitHub e inicia sesión.
2. Crea un repositorio público llamado `portafolio`.
3. Sube `index.html`.
4. Ve a **Settings → Pages**.
5. En **Build and deployment**, selecciona **Deploy from a branch**.
6. Selecciona la rama `main` y la carpeta `/ (root)`.
7. Guarda y espera unos minutos.

La dirección quedará con un formato similar a:
`https://karturval1526.github.io/portafolio/`

Ese enlace es el que debes colocar en el campo **Enlace de portafolio** de la vacante.
